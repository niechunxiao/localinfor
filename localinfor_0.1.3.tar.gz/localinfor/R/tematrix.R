#' A function that calculates a transfer entropy matrix.
#'
#' @param s Each column of the time series S corresponds to a variable, and each row corresponds to a set of observations.
#' @param lagx A parameter for selecting the time lag order.
#' @param lagy A parameter for selecting the time lag order.
#' @param qc Quantile parameters used to discretize time series.
#'
#' @return Transfer entropy matrix
#' @export
#'
#' @examples s1=matrix(0,1001,6)
#'  s1[,1]=rnorm(1001,0,1)
#'  s1[,4]=rnorm(1001,0,1)
#'  for (i in 2:1001){s1[i,2]=s1[c(i-1),1]^2+rnorm(1,0,0.2)
#'  s1[i,3]=s1[c(i-1),1]^3+rnorm(1,0,0.2)
#'  s1[i,5]=abs(s1[c(i-1),4])+rnorm(1,0,0.2)
#'  s1[i,6]=abs(s1[c(i-1),4])+s1[c(i-1),1]+rnorm(1,0,0.2)}
#'  s=s1[2:1001,]
#'  tem=tematrix(s,1,1,c(25,50,75))
tematrix<-function(s,lagx,lagy,qc){
  n=dim(s)
  cn=t(combn(n[2],2))
  m=dim(cn)
  m1=m[1]
  tem=matrix(0,n[2],n[2])
  for (i in 1:m1){
    tem[cn[i,1],cn[i,2]]= calc_te(s[,cn[i,1]],s[,cn[i,2]],lx = lagx,ly = lagy,entropy = "Shannon",type = "quantiles",quantiles = qc)
  }
  for (i in 1:m1){
    tem[cn[i,2],cn[i,1]]= calc_te(s[,cn[i,2]],s[,cn[i,1]],lx = lagx,ly = lagy,entropy = "Shannon",type = "quantiles",quantiles = qc)
  }
  return(tem)
}
