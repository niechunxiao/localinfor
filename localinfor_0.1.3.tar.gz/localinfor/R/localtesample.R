#' This function is used to calculate the distribution of the benchmark TE values.
#'
#' @param s1 The first time series.
#' @param s2 The second time series.
#' @param w The vector w is the parameter of the calculation window.
#' @param nrand The parameter nrand is used to set the number of benchmark TE values.
#' @param qc The parameter qc is a quantile vector that computes the TE value.
#'
#' @return The distribution of the benchmark TE values.
#' @export
#'
#' @examples data(model01)
#' terand=localtesample(model01$x,model01$y,c(200,300),100,1,1,c(25,50,75))
localtesample<-function(s1,s2,w,nrand,lx,ly,qc){
  #This function is used to generate a distribution of LRP-based TE values, where m is the number of samples.
  randte<-matrix(NA,1,nrand)
  for (i in 1:nrand){
    randte[,i]<-localte(s1,s2,w,lx,ly,qc)
  }
  return(randte)
}
