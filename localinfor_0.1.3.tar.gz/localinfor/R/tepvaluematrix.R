#' A function that calculates the transfer entropy matrix (p-value).
#'
#' @param s Each column of the time series S corresponds to a variable, and each row corresponds to a set of observations.
#' @param lagx A parameter for selecting the time lag order.
#' @param lagy A parameter for selecting the time lag order.
#' @param qc Quantile parameters used to discretize time series.
#' @param nboot The parameter used to calculate the p-value.
#'
#' @return A list that includes a transfer entropy matrix and a p-value matrix.
#' @export
#'
#' @examples s1=matrix(0,1001,6)
#'  s1[,1]=rnorm(1001,0,1)
#'  s1[,4]=rnorm(1001,0,1)
#'  for (i in 2:1001){s1[i,2]=s1[c(i-1),1]^2+rnorm(1,0,0.2)
#'  s1[i,3]=s1[c(i-1),1]^3+rnorm(1,0,0.2)
#'  s1[i,5]=abs(s1[c(i-1),4])+rnorm(1,0,0.2)
#'  s1[i,6]=abs(s1[c(i-1),4])+s1[c(i-1),1]+rnorm(1,0,0.2)}
#'  s=s1[2:1001,]
#'  temp=tepvaluematrix(s,1,1,c(25,50,75),100)
tepvaluematrix<-function(s,lagx,lagy,qc,nboot){
  n=dim(s)
  tem=matrix(0,n[2],n[2])
  tep=matrix(0,n[2],n[2])
  cn=t(combn(n[2],2))
  m=dim(cn)
  v=matrix(0,m[1],4)
  for (i in 1:m[1]){
    v[i,]=tepvector(s[,cn[i,1]],s[,cn[i,2]],lagx,lagy,qc,nboot)
  }
  for (i in 1:m[1]){
    tem[cn[i,1],cn[i,2]]=v[i,1]
    tem[cn[i,2],cn[i,1]]=v[i,3]
    tep[cn[i,1],cn[i,2]]=v[i,2]
    tep[cn[i,2],cn[i,1]]=v[i,4]
  }
  output=list(tem=tem,tep=tep)
  return(output)
}
