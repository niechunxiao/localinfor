#' A function of the threshold network that is calculated by the information matrix.
#'
#' @param e Information matrix
#' @param th Threshold
#'
#' @return A list consisting of two matrices, where adje is a 0-1 adjacency matrix and adjweig is an adjacency matrix with edge weights.
#' @export
#'
#' @examples s1=matrix(0,1001,6)
#'  s1[,1]=rnorm(1001,0,1)
#'  s1[,4]=rnorm(1001,0,1)
#'  for (i in 2:1001){s1[i,2]=s1[c(i-1),1]^2+rnorm(1,0,0.2)
#'  s1[i,3]=s1[c(i-1),1]^3+rnorm(1,0,0.2)
#'  s1[i,5]=abs(s1[c(i-1),4])+rnorm(1,0,0.2)
#'  s1[i,6]=abs(s1[c(i-1),4])+s1[c(i-1),1]+rnorm(1,0,0.2)}
#'  s=s1[2:1001,]
#'  tem=tematrix(s,1,1,c(25,50,75))
#'  adjm=infornetwork(tem,0.06)
infornetwork<-function(e,th){
  adje=ifelse(e>=th,1,0)
  n=dim(e)
  for (i in 1:n[2]){
    adje[i,i]=0
  }
  adjweig=e*adje
  output=list(adje=adje,adjweig=adjweig)
  return(output)
}
