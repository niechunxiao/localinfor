#' This function is used to analyze the dynamics of the information flow.
#'
#' @param s1 The first time series.
#' @param s2 The second time series.
#' @param Lw The parameter Lw is the length of the calculation window.
#' @param nrand The parameter nrand is used to set the number of benchmark TE values.
#' @param qc The parameter qc is a quantile vector that computes the TE value.
#'
#' @return A list that includes z-scores, p-values, and TE values. (Ref: Nie, C. X. (2021). Dynamics of the price–volume information flow based on surrogate time series. Chaos: An Interdisciplinary Journal of Nonlinear Science, 31(1), 013106.)
#' @export
#'
#' @examples data(model02)
#' te=localteseries(model02$x,model02$y,100,100,1,1,c(25,50,75))
localteseries<-function(s1,s2,Lw,nrand,lx,ly,qc){
  #This function is used to calculate the dynamics of the information flow for two time series.
  n<-length(s1)-Lw+1
  randte<-matrix(NA,n,nrand)
  for (i in 1:n){
    randte[i,]<-localtesample(s1,s2,c(i,Lw+i-1),nrand,lx,ly,qc)
  }

  tevalue=calc_te(s1,s2, lx = 1, ly = 1, entropy = "Shannon",  shuffles = 100, type = "quantiles", quantiles = qc, bins = NULL, limits = NULL, burn = 50, seed = NULL)

  testatistics<-matrix(NA,n,2)
  for (i in 1:n){
    testatistics[i,]<-c(mean(randte[i,]),sd(randte[i,]))
  }

  zscore<-matrix(NA,n)
  pvalue<-matrix(NA,n)
  for (i in 1:n){
    zscore[i]=(tevalue-testatistics[i,1])/testatistics[i,2]
    pvalue[i]=pnorm(zscore[i], mean = 0, sd = 1, lower.tail = FALSE,log.p = FALSE)
  }


  output=list(tevalue=tevalue,zscore=zscore,pvalue=pvalue,testatistics=testatistics,randte=randte)

  return(output)
}
