#' A function that calculates the transfer entropy values and the p-values.
#'
#' @param x The first time series.
#' @param y The second time series.
#' @param lagx A parameter for selecting the time lag order.
#' @param lagy A parameter for selecting the time lag order.
#' @param qc Quantile parameters used to discretize time series.
#' @param nboot The parameter used to calculate the p-value.
#'
#' @return A vector where the first and third components are TE values and the second and fourth components are p-values.
#' @export
#'
#' @examples data(model02)
#' tev=tepvector(model02$x,model02$y,1,1,c(25,50,75),100)
tepvector<-function(x,y,lagx,lagy,qc,nboot){
  te=transfer_entropy(x,y,lx = lagx,ly = lagy, entropy = "Shannon",shuffles = 100,type = "quantiles",quantiles = qc,nboot = nboot)
  v=as.matrix(te$coef)
  tep=c(v[1,1],v[1,4],v[2,1],v[2,4])
  return(tep)
}
